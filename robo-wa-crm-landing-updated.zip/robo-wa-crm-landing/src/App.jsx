import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import {
  MessageCircle,
  Users,
  Calendar,
  Tag,
  FileText,
  BarChart3,
  Send,
  Bot,
  Smartphone,
  Zap,
  CheckCircle,
  Play,
  ArrowRight,
  Star,
  Globe
} from 'lucide-react'
import './App.css'

function App() {
  const features = [
    { icon: MessageCircle, text: "Respostas rápidas! Categorias, scripts e muito mais!" },
    { icon: Send, text: "Mensagens em massa! Texto, áudio, imagens, vídeos, arquivos, contatos, listas, documentos, enquetes..." },
    { icon: BarChart3, text: "Painel Kanban!" },
    { icon: Calendar, text: "Agendamento de mensagens!" },
    { icon: Tag, text: "Tags e etiquetas!" },
    { icon: FileText, text: "Importe e exporte contatos!" },
    { icon: BarChart3, text: "Relatórios completos!" },
    { icon: Users, text: "Disparos em massa! Kanban, etiquetas, grupos... e até por abas!" },
    { icon: MessageCircle, text: "Disparo no privado!" },
    { icon: Users, text: "Disparo em grupos! E se quiser... com aquela marcação fantasma, super discreta!" },
    { icon: Bot, text: "TypeBot (Fluxo de conversa com PC desligado)" },
    { icon: Calendar, text: "Lembretes!" },
    { icon: FileText, text: "Modelos de mensagens prontas!" },
    { icon: CheckCircle, text: "Assinatura exclusiva do atendente!" },
    { icon: FileText, text: "Adicione notas, tarefas e lembretes! Tudo no mesmo lugar." },
    { icon: Bot, text: "Auto responder!" },
    { icon: CheckCircle, text: "Suporte de domingo a domingo!" },
    { icon: Zap, text: "Atualizações constantes e sem custo!" },
    { icon: BarChart3, text: "Funil de mensagens!" },
    { icon: MessageCircle, text: "Envie áudios como se fossem gravados na hora! É isso mesmo que você ouviu!" }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-green-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bot className="h-8 w-8 text-green-600" />
              <span className="text-xl font-bold text-gray-800">Robô Wa Crm Web</span>
            </div>
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={() => window.open('https://wa.me/5521998484383', '_blank')}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Falar Agora
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <Badge className="mb-6 bg-green-100 text-green-800 hover:bg-green-200">
              🤖 Automação WhatsApp
            </Badge>
            
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Transforme Seu Celular em uma 
              <span className="text-green-600 block">Máquina de Vendas</span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Seu celular não precisa ser apenas um dispositivo comum. Com o Robô Wa Crm Web, 
              ele se torna uma poderosa ferramenta de automação para divulgação e gerenciamento no WhatsApp.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                size="lg" 
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 text-lg"
                onClick={() => window.open('https://wa.me/5521998484383', '_blank')}
              >
                <MessageCircle className="h-5 w-5 mr-2" />
                Começar Agora
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline" 
                className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-4 text-lg"
                onClick={() => window.open('https://youtu.be/mKJUWO-C9L8?si=1eydUZJp3afMxahd', '_blank')}
              >
                <Play className="h-5 w-5 mr-2" />
                Ver Demonstração
              </Button>
            </div>

            <div className="flex items-center justify-center space-x-8 text-sm text-gray-500">
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                Suporte 7 dias
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                Atualizações gratuitas
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                ChatGPT integrado
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              🎙️ "VEJA TODAS AS FUNÇÕES DO WA CRM!"
            </h2>
            
            <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-black">
              <iframe
                width="100%"
                height="500"
                src="https://www.youtube.com/embed/mKJUWO-C9L8?si=1eydUZJp3afMxahd&autoplay=1&mute=1&loop=1&playlist=mKJUWO-C9L8"
                title="Demonstração Robô Wa Crm Web"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                loading="lazy"
                className="w-full"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              🔹 O Que o Robô Wa Crm Web Oferece?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Chegou a hora de levar suas estratégias de marketing e organização de grupos a outro nível!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300 border-green-100">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <feature.icon className="h-6 w-6 text-green-600" />
                    </div>
                    <p className="text-gray-700 leading-relaxed">
                      👉 {feature.text}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ChatGPT Integration Section */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
              <CardContent className="p-8">
                <Globe className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  🌐 INTEGRAÇÃO CHATGPT GRATUITA
                </h3>
                <p className="text-lg text-gray-700 mb-6">
                  Recursos avançados de IA inclusos: procurar, transcrição de áudio, ortografia, 
                  traduzir, resumir, prolongar, amigável, formal
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {['Procurar', 'Transcrição', 'Ortografia', 'Traduzir', 'Resumir', 'Prolongar', 'Amigável', 'Formal'].map((feature) => (
                    <Badge key={feature} variant="secondary" className="bg-blue-100 text-blue-800">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Pronto para Revolucionar suas Vendas?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Clique aqui para conhecer melhor e começar agora!
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button 
                size="lg" 
                className="bg-white text-green-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
                onClick={() => window.open('https://wa.me/5521998484383', '_blank')}
              >
                <MessageCircle className="h-5 w-5 mr-2" />
                Falar com Especialista
              </Button>
              
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white/10 px-8 py-4 text-lg"
                onClick={() => window.open('https://chat.whatsapp.com/FEUncoVPGZo0Gxn99HV99f', '_blank')}
              >
                <Users className="h-5 w-5 mr-2" />
                Entrar no Grupo
              </Button>
            </div>

            <div className="flex items-center justify-center space-x-6 text-sm opacity-80">
              <div className="flex items-center">
                <Star className="h-4 w-4 mr-1" />
                Avaliação 5 estrelas
              </div>
              <div className="flex items-center">
                <Smartphone className="h-4 w-4 mr-1" />
                Funciona em qualquer celular
              </div>
              <div className="flex items-center">
                <Zap className="h-4 w-4 mr-1" />
                Configuração rápida
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <Bot className="h-8 w-8 text-green-400" />
            <span className="text-2xl font-bold">Robô Wa Crm Web</span>
          </div>
          
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            Transforme seu WhatsApp em uma poderosa ferramenta de vendas e atendimento. 
            Automação inteligente para resultados extraordinários.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button 
              variant="outline" 
              className="border-green-400 text-green-400 hover:bg-green-400 hover:text-gray-900"
              onClick={() => window.open('https://wa.me/5521998484383', '_blank')}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              WhatsApp
            </Button>
            
            <Button 
              variant="outline" 
              className="border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-gray-900"
              onClick={() => window.open('https://youtu.be/mKJUWO-C9L8?si=1eydUZJp3afMxahd', '_blank')}
            >
              <Play className="h-4 w-4 mr-2" />
              YouTube
            </Button>
            
            <Button 
              variant="outline" 
              className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-gray-900"
              onClick={() => window.open('https://chat.whatsapp.com/FEUncoVPGZo0Gxn99HV99f', '_blank')}
            >
              <Users className="h-4 w-4 mr-2" />
              Grupo
            </Button>
          </div>
          
          <div className="border-t border-gray-800 pt-6">
            <p className="text-gray-500 text-sm">
              © 2024 Robô Wa Crm Web. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App


